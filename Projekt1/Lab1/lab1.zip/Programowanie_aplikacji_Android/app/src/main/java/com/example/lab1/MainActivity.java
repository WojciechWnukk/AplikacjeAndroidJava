package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private EditText nameEditText;
    private EditText surnameEditText;
    private EditText numberEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        nameEditText = findViewById(R.id.name);
        surnameEditText = findViewById(R.id.surname);
        numberEditText = findViewById(R.id.number);
        nameEditText.addTextChangedListener(nameTextWatcher);
        surnameEditText.addTextChangedListener(surnameTextWatcher);
        numberEditText.addTextChangedListener(numberTextWatcher);
        button.setVisibility(View.INVISIBLE);
    }



    private boolean isNameValid(String name) {
        boolean isValid = !TextUtils.isEmpty(name);
        if (!isValid) {
            nameEditText.setError("Pole imienia nie może być puste.");
        } else {
            nameEditText.setError(null);
        }
        return isValid;
    }
    private boolean isSurnameValid(String surname) {
        boolean isValid = !TextUtils.isEmpty(surname);
        if (!isValid) {
            surnameEditText.setError("Pole nazwiska nie może być puste.");
        } else {
            surnameEditText.setError(null);
        }
        return isValid;
    }
    /*
    private boolean isNumberValid(String number) {
        boolean isValid;
        try {
            int value = Integer.parseInt(number);
            isValid = value >= 5 && value <= 15;
        } catch (NumberFormatException e) {
            isValid = false;
            Toast.makeText(getApplicationContext(), "Wartość pola liczby musi być z przedziału od 5 do 15.", Toast.LENGTH_SHORT).show();
            numberEditText.setError("Nieprawidłowa wartość liczby");
        }

        if (!isValid) {
            numberEditText.setError(null);
        }
        return isValid;
    }
*/
    private boolean isNumberValid(String number) {
        try {
            int value = Integer.parseInt(number);
            return value >= 5 && value <= 15;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    TextWatcher nameTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // sprawdź, czy dane w polu imienia są poprawne
            boolean isNameValid = isNameValid(s.toString());

            // włącz lub wyłącz przycisk na podstawie wyniku
            button.setVisibility(isNameValid && isNumberValid(numberEditText.getText().toString()) && isSurnameValid(surnameEditText.getText().toString()) ? View.VISIBLE : View.INVISIBLE);

        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    TextWatcher surnameTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // sprawdź, czy dane w polu imienia są poprawne
            boolean isSurnameValid = isSurnameValid(s.toString());

            // włącz lub wyłącz przycisk na podstawie wyniku
            button.setVisibility(isNameValid(nameEditText.getText().toString()) && isNumberValid(numberEditText.getText().toString())  && isSurnameValid ? View.VISIBLE : View.INVISIBLE);

        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    TextWatcher numberTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            boolean isNumberValid = isNumberValid(s.toString());

            if (!isNumberValid) {
                Toast.makeText(getApplicationContext(), "Wartość pola liczby musi być z przedziału od 5 do 15.", Toast.LENGTH_SHORT).show();
                numberEditText.setError("Nieprawidłowa wartość liczby");
            } else {
                numberEditText.setError(null);
            }

            button.setVisibility(isNumberValid && isNameValid(nameEditText.getText().toString()) && isSurnameValid(surnameEditText.getText().toString()) ? View.VISIBLE : View.INVISIBLE);
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
}